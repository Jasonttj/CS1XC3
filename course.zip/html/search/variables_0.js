var searchData=
[
  ['code_0',['code',['../struct__course.html#a17e6787fbe54ae62b01802024bd1544d',1,'_course']]]
];
